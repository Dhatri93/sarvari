package com.vinayak09.wsafety;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.IBinder;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.github.tbouron.shakedetector.library.ShakeDetector;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.util.ArrayList;

public class ServiceMine extends Service {
    private SpeechRecognizer speechRecognizer;
    private Intent recognizerIntent;
    boolean isRunning = false;
    boolean listening=false;

    FusedLocationProviderClient fusedLocationClient;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    SmsManager manager = SmsManager.getDefault();
    String myLocation;


    void initiateSpeech(){

        // Initialize SpeechRecognizer and Intent
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(getApplicationContext());
        recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechRecognizer.startListening(recognizerIntent);

        // Set up the recognition listener
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                // Called when the listener is ready to receive speech input
            }

            @Override
            public void onBeginningOfSpeech() {
                // Called when the user starts speaking
            }

            @Override
            public void onRmsChanged(float rmsdB) {
                // Called when the RMS value of the audio changes
            }

            @Override
            public void onBufferReceived(byte[] buffer) {
                // Called when sound has been received
            }

            @Override
            public void onEndOfSpeech() {
                // Called when the user stops speaking
            }

            @Override
            public void onError(int error) {
                // Called when an error occurs during recognition
              //  String errorMessage = "Error " + error;
               // speechResultTextView.setText(errorMessage); add toast msg here
              //  Toast.makeText(getApplicationContext(),errorMessage,Toast.LENGTH_LONG).show();

            }

            @Override
            public void onResults(Bundle results) {
                // Called when recognition is successful
                ArrayList<String> voiceResults = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);

                if (voiceResults != null) {
                    for (String result : voiceResults) {
                        if (result.toLowerCase().contains("hello")) {
//                            speechResultTextView.setText("You said: " + result);
                            Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG).show();

                            // add toast msg here
                            break;
                        }
                    }
                }
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
                // Called when partial recognition results are available
            }

            @Override
            public void onEvent(int eventType, Bundle params) {
                // Called when an event related to recognition occurs
            }
        });

        if (!listening) {
            listening = true;
//            speechResultTextView.setText("Listening...");
            Toast.makeText(getApplicationContext(),"Listning ",Toast.LENGTH_LONG).show();

            speechRecognizer.startListening(recognizerIntent);
        }
//        else {
//            listening = false;
////            speechResultTextView.setText("");
//            Toast.makeText(getApplicationContext(),"Listning false",Toast.LENGTH_LONG).show();
//            speechRecognizer.stopListening();
//        }
    }

    @Override
    public void onCreate() {
//        super.onCreate();

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            Toast.makeText(getApplicationContext(),"location not null",Toast.LENGTH_LONG).show();
                            // Logic to handle location object
//                            location.getAltitude();
//                            location.getLongitude();
                            myLocation = "http://maps.google.com/maps?q=loc:" + location.getLatitude() + "," + location.getLongitude();
                        } else {
                            myLocation = "Unable to Find Location :(";
                        }
                    }
                });

//        speechrec();
       // initiateSpeech();
    }
        void speechrec() {

            SpeechRecognizer recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle params) {
                    Toast.makeText(getApplicationContext(),"on get ready",Toast.LENGTH_LONG).show();
                }

                @Override
                public void onBeginningOfSpeech() {

                }

                @Override
                public void onRmsChanged(float rmsdB) {

                }

                @Override
                public void onBufferReceived(byte[] buffer) {

                }

                @Override
                public void onEndOfSpeech() {

                }

                @Override
                public void onError(int error) {

                }

                @Override
                public void onResults(Bundle results) {
                    ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) {
                        String recognizedText = matches.get(0).toLowerCase();
                        if (recognizedText.contains("hello")) {
                            // Keyword detected, perform your desired action
                            SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                            String ENUM = sharedPreferences.getString("ENUM", "NONE");
                            if (!ENUM.equalsIgnoreCase("NONE")) {
                                manager.sendTextMessage(ENUM, null, "Im in Trouble!\nSending My Location :\n" + myLocation, null, null);
                            }
                        }
                    }
                }

                @Override
                public void onPartialResults(Bundle partialResults) {

                }

                @Override
                public void onEvent(int eventType, Bundle params) {

                }

                // Implement other listener methods as needed
            });



        }



    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Toast.makeText(this,"onstart command", Toast.LENGTH_SHORT).show();


            if (intent.getAction().equalsIgnoreCase("STOP")) {
                if(isRunning) {
                    this.stopForeground(true);
                    this.stopSelf();
                }
            } else {


                Intent notificationIntent = new Intent(this, MainActivity.class);
                PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);

                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    NotificationChannel channel = new NotificationChannel("MYID", "CHANNELFOREGROUND", NotificationManager.IMPORTANCE_DEFAULT);

                    NotificationManager m = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    m.createNotificationChannel(channel);

                    Notification notification = new Notification.Builder(this, "MYID")
                            .setContentTitle("Women Safety")

                            .setSmallIcon(R.drawable.girl_vector)
                            .setContentIntent(pendingIntent)
                            .build();
                    this.startForeground(115, notification);
                    isRunning = true;

                    SmsManager sm= SmsManager.getDefault();
                    String phoneNumber = "9177824544";

// Message to send
                    String message = "i am in trouble "+myLocation;


                    PendingIntent sentIntent = PendingIntent.getBroadcast(this, 0,
                            new Intent("SMS_SENT"), 0);

// Send the SMS
                    sm.sendTextMessage(phoneNumber, null, message, sentIntent, null);
                    return START_NOT_STICKY;
                }
            }

        return super.onStartCommand(intent,flags,startId);


    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
    }
}
